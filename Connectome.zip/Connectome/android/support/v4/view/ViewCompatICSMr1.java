package android.support.v4.view;

import android.view.View;

class ViewCompatICSMr1 {
    ViewCompatICSMr1() {
    }

    public static boolean hasOnClickListeners(View v) {
        return v.hasOnClickListeners();
    }
}
